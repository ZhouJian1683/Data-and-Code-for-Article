
% 根据适应度值进行选择概率的计算

function proba_choose = calcu_proba(fitness_value)
    
    proba_choose = cumsum(fitness_value / sum(fitness_value));
    
%     for i = 2 : popsize
%         proba_single(i) = fitness_value(i) / sum(fitness_value);
%         proba_choose(i) = proba_single(i) + proba_choose(i - 1);
%     end
    
    % 至此，得到各染色体被选择的概率

end
