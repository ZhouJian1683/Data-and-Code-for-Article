
% 计算适应度

function [fitness_value, pro] = fitness (pop_repaired)
    
    global N_q cost_chidao  cost_work  cost_diff  cost_tr  M_pre  ED  best_position  cost_delay    N_v   W_u  W_d  cost_stay  sample  g   L_m L % popsize
    
    % cost_zaodao = 0.9;    % 船舶提前到港单位时间成本
    
    % 适应度函数为目标函数倒数，目标函数包括码头间转运成本、延误离港惩罚成本、作业成本、泊位偏移成本
    
    % 判断指标：
    % 1、目标函数值；
    % 2、船舶的即到即靠率；-----实际到港时间与实际靠泊时间相同的船舶所占比例
    % 3、船舶的延误离港率；-----实际离港时间超过期望离港时间的船舶所占比例
    % 4、船舶延迟到港率；-------实际到港时间超过调度靠泊时间的船舶所占比例
    % 5、岸线利用率；
    % 6、岸桥利用率；
    
    % 对每个染色体进行适应度计算
    object_value = zeros(size(pop_repaired, 1), size(sample{1, 1}, 1));  % 各染色体在各样本下的目标函数值集合初始化
    object_value_mean = zeros(1, size(pop_repaired, 1));    % 各染色体在所有样本下所得目标函数值的期望集合初始化
    object_value_std = zeros(1, size(pop_repaired, 1));    % 各染色体在所有样本下所得目标函数值的方差集合初始化
    fitness_value = zeros(1, size(pop_repaired, 1));    % 各染色体的适应度值
    pro = zeros(8, size(pop_repaired, 1));
    % pro(1, :) = pro_same = zeros(1, popsize);    % 船舶即到即靠率
    % pro(2, :) = pro_delay_leave = zeros(1, popsize);    % 船舶延误离港率
    % pro(3 : ) = pro_delay_arrive = zeros(1, popsize);    % 船舶延误靠泊率
    % pro(4: 6, : ) = pro_quay_use = zeros(3, popsize);    % 各码头岸线利用率
    % pro(7, :) = pro_all_quay_use = zeros(1, popsize);     % 总的岸线利用率
    % pro(8, :) = pro_crane_use = zeros(1, popsize);    % 总的岸桥利用率
    
    
    % 在计算岸线利用率时还需要将计划期开始时已靠泊船舶计算进去
    % 首先得到各码头已靠泊船舶数据（船身长度、离港时间两项）
    vessel_already = find_vessel_already();
    
    for i = 1 : size(pop_repaired, 1)
        
        num_same = 0;    % 实际到港时间与实际靠泊时间相同的船舶数量
        num_delay_leave = 0;    % 实际离港时间超过期望离港时间的船舶数量
        num_delay_arrive = 0;    % 实际到港时间超过调度靠泊时间的船舶数量
        num_early_arrive = 0;    % 实际到港时间早于调度靠泊时间的船舶数量
        num_quay_use = zeros(1, 3);    % 各码头岸线总利用长度时间 N_m
        num_crane_use = zeros(1, 3);    % 各码头岸桥总利用作业时
        
        % 计算已靠泊船舶所占用的岸线资源长度时间
        for j = 1 : 3
            % 向量化编程
            num_quay_use(1, j) = sum(vessel_already{1, j}(3, : ) .* vessel_already{1, j}(5, : ));
            num_quay_use(1, j) = num_quay_use(1, j) * size(sample{1, 1}, 1);     %  需要计算样本数量次
            num_crane_use(1, j) = sum(vessel_already{1, j}(3, : ) .* vessel_already{1, j}(6, : ));
            num_crane_use(1, j) = num_crane_use(1, j) * size(sample{1, 1}, 1);     %  需要计算样本数量次
        end
        
        % 先确定待调度船舶的最终停靠码头是否为其预分配码头，得到矩阵is_change_terminal
        % 向量化编程
        is_change_terminal = zeros(1, N_v);    % 判断船舶的实际停靠码头是否为其预分配码头
        is_change_terminal(pop_repaired(i, 1 : N_v) == M_pre) = 1;
        % 至此，得到船舶是否更改其码头信息
        
        for k = 1 : size(sample{1, 1}, 1)
            
            % 向量化编程
            % 实际离港时间计算
            num_delay_arrive = num_delay_arrive + length(find(pop_repaired(i, 2*N_v+1 : 3*N_v) < sample{1, 1}(k, : )));
            num_same = num_same + length(find(pop_repaired(i, 2*N_v+1 : 3*N_v) == sample{1, 1}(k, : )));
            num_early_arrive = num_early_arrive + length(find(pop_repaired(i, 2*N_v+1 : 3*N_v) > sample{1, 1}(k, : )));
            sample{1, 3}(k, : ) = max(sample{1, 1}(k, : ), pop_repaired(i, 2*N_v +1 : 3*N_v)) + round( (W_u + W_d) ./ (sample{1, 2}(k, : ) .* pop_repaired(i, 3*N_v+1 : 4*N_v) .* (g .^ (pop_repaired(i, 3*N_v+1 : 4*N_v) - 1))), 1);
            num_delay_leave = num_delay_leave + length(find(sample{1, 3}(k, : ) > ED));

            % 计算待调度船舶所占用的岸线资源长度时间
            temp = pop_repaired(i, 2*N_v+1 : 3*N_v);
            temp_crane = pop_repaired(i, 3*N_v+1 : 4*N_v);
            for j = 1 : 3
                % 向量化编程
                num_quay_use(1, j) = num_quay_use(1, j) + sum(L(pop_repaired(i, 1 : N_v) == j) .* ( sample{1, 3}(k, pop_repaired(i, 1 : N_v) == j) - max(temp(pop_repaired(i, 1 : N_v) == j), sample{1, 1}(k, pop_repaired(i, 1 : N_v) == j))));      % 船身长度*在港时间
                num_crane_use(1, j) = num_crane_use(1, j) + sum(temp_crane(pop_repaired(i, 1 : N_v) == j) .* ( sample{1, 3}(k, pop_repaired(i, 1 : N_v) == j) - max(temp(pop_repaired(i, 1 : N_v) == j), sample{1, 1}(k, pop_repaired(i, 1 : N_v) == j))));        % 岸桥数量×作业时间
            end
            
            % 目标函数值计算
            % 向量化编程，缩短运行时间
            object_value(i, k) = object_value(i, k) + sum(cost_work * pop_repaired(i, 3*N_v+1 : 4*N_v) .* ( sample{1, 3}(k, : ) - max(temp, sample{1, 1}(k, : )) ) );    %  单位作业成本×岸桥数量×在港时间
%             disp("-------总作业成本-------");
%             disp(sum(cost_work * pop_repaired(i, 3*N_v+1 : 4*N_v) .* ( sample{1, 3}(k, : ) - max(temp, sample{1, 1}(k, : )) ) ));
            object_value(i, k) = object_value(i, k) + sum(cost_diff * (W_u + W_d) .* (abs( pop_repaired(i, N_v+1 : 2*N_v)-best_position )/10) .* is_change_terminal );    %  单位偏离成本×装卸量×偏离距离
%             disp("-------总偏离成本-------");
%             disp(sum(cost_diff * (W_u + W_d) .* (abs( pop_repaired(i, N_v+1 : 2*N_v)-best_position )) .* is_change_terminal ));
            object_value(i, k) = object_value(i, k) + sum(cost_chidao * (W_u + W_d) .* max(sample{1, 1}(k, : ) - pop_repaired(i, 1 +2*N_v : 3*N_v), 0));    % 单位延误到港成本×迟到时间
%             disp("-------总延误到港成本-------");
%             disp(sum(cost_chidao * (W_u + W_d) .* max(sample{1, 1}(k, : ) - pop_repaired(i, 1 +2*N_v : 3*N_v), 0)));
            object_value(i, k) = object_value(i, k) + sum(cost_stay * W_d .* max(pop_repaired(i, 1+2*N_v : 3*N_v) - sample{1, 1}(k, : ), 0));    % 单位等待成本×等待时间
%             disp("-------总等待成本-------");
%             disp(sum(cost_stay * W_d .* max(pop_repaired(i, 1+2*N_v : 3*N_v) - sample{1, 1}(k, : ), 0)));
            object_value(i, k) = object_value(i, k) + sum(cost_delay .* W_u .* max(sample{1, 3}(k, : ) - pop_repaired(i, 5*N_v+1 : 6*N_v), 0));    % 单位延误离港成本×离港时间
%             disp("-------总延误离港成本-------");
%             disp(sum(cost_delay .* W_u .* max(sample{1, 3}(k, : ) - pop_repaired(i, 5*N_v+1 : 6*N_v), 0)));
%             temp_1 = object_value(i, k);
            for l = 1 : size(sample{1, 1}, 2)
                if is_change_terminal(1, l) == 0   % 只有在靠泊码头改变时才计算转运成本
                    object_value(i, k) = object_value(i, k) + cost_tr(M_pre(l), pop_repaired(i, l)) * W_u(l);    % 单位转运成本×转运箱量
                end
            end
%             disp("-------总转运成本-------");
%             disp(object_value(i, k)-temp_1);
            
        end
        % 至此，得到所有在染色体 i 所表示的解下可行样本的目标函数值
        
        % 计算期望及方差，得到适应度函数值
        object_value_mean(i) = sum(object_value(i, :)) / size(object_value, 2);     % 所有可行样本函数值的期望
%         disp(object_value_mean(i));
        object_value_std(i) = std(object_value(i, :));     % 所有可行样本函数值的标准差
%         disp(10*object_value_std(i));
        fitness_value(1, i) = 500000 / (object_value_mean(i) + 10 * object_value_std(i));    % 各染色体的适应度值
%         disp(fitness_value(1, i));
        % 至此，得到染色体 i 的适应度值
        
        % 计算各染色体的评价指标：
        pro(1, i) = num_same / (size(sample{1, 1}, 1) * size(sample{1, 1}, 2));          % 1、船舶即到即靠率 = 即到即靠船舶数量 /（样本数量 × 船舶数量）
        pro(2, i) = num_delay_leave / (size(sample{1, 1}, 1) * size(sample{1, 1}, 2));       % 2、船舶离港延误率 = 延误离港船舶数量 /（样本数量 × 船舶数量）
        pro(3, i) = num_delay_arrive / (size(sample{1, 1}, 1) * size(sample{1, 1}, 2));       % 3、船舶靠泊延误率 = 靠泊延误船舶数量 /（样本数量 × 船舶数量）
%         max_time = zeros(1, 3);
        for j = 1 : 3
%             max_time(1, j) = sum(max( sample{1, 3}( : , pop_repaired(i, 1 : N_v) == j) , [], 2 ));
            pro(j+3, i) = num_quay_use(1, j) / (L_m(j) * 96 * size(sample{1, 1}, 1));      % 4、码头 i 岸线利用率 = （停靠在码头 i 的船舶长度 × 船舶靠泊时间）/（计划期长度 × 岸线长度）
        end
        % 至此，得到染色体 i 的评价指标值
        
        % 加上所有码头整个岸线的利用率
        pro(7, i) = sum(num_quay_use) / sum(96 * size(sample{1, 1}, 1) * L_m);
        
        % 加上所有岸桥的利用率
        pro(8, i) = sum(num_crane_use) / sum(96 * size(sample{1, 1}, 1) * N_q);
        
        % 至此，得到染色体 i 的评价指标值
        
    end
    % 至此，得到所有染色体的适应度值
end






















