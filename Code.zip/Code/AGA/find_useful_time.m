function time_useful = find_useful_time(start, draft, d_m)
time_useful = [];
%  输入：船舶水深（1×1）、码头水深（1×72）、start: 船舶的计划靠泊时刻向下取整
%  输出：可用时间集合（2×num）
%  找出船舶的可靠泊时间段集合
if start == 0
    start = 1;
end
if start <= size(d_m, 2)
    if_can = zeros(1, size(d_m, 2) - start + 1);  % 定义一个与各时间点的水深矩阵相等大小的矩阵，
else
    disp('something is wrong!');
end

%  首先进行判断各时间点的码头水深是否满足吃水要求，若满足，其值为1，否则，为0。
% for i = 1 : size(if_can, 2)  % 对计划期内的各时间点
%     if d_m(1, start+i-1) < draft  % 判断码头水深是否小于船舶吃水要求
%         if_can(1, i) = 0;   % 若是，则将值设为0
%     else
%         if_can(1, i) = 1;   % 否则，将值设为1
%     end
% end
% num = 0;  % 用于记录可用时间段的数量
% % 先判断 t=1 时是否可以靠泊
% if if_can(1, 1) == 1
%     num = num+1;   % 可用时间段+1
%     time_useful(1, num) = start;   % 第一段可用时间段的起点
% end
% % [0, 1, 1, 1, 0, 1, 1, 1, 0]
% % [1, 1, 0, 0, 1, 1, 1, 1, 0]
% % [1, 1, 1, 0, 1, 1, 1, 0, 1, 1]
% for i = 2 : size(if_can, 2)
%     if if_can(1, i) - if_can(1, i-1) == 1
%         num = num+1;   % 可用时间段+1
%         time_useful(1, num) = start+i-1;  % 第 num 段可用时间段的起点
%     elseif if_can(1, i) - if_can(1, i-1) == -1
%         time_useful(2, num) = start+i-2;  % 第 num 段可用时间段的终点
%     end
% end
% %  最后，还需要判断最后一个时刻是否可以靠泊
% if if_can(1, size(if_can, 2)) == 1
%     time_useful(2, num) = start + size(if_can, 2) - 1;    % 最后一段可用时间段的终点
% end

% 进行向量化编程，缩短运行时间
% 通过前后各加上0生成两个新矩阵
if_can( d_m(start : size(d_m, 2)) >= draft) = 1;
temp_1 = [if_can, 0];
temp_2 = [0, if_can];
% 将两个矩阵相减
diff = temp_1 - temp_2;
time_useful(1, :) = start + find(diff==1) - 1;      % 起始坐标
time_useful(2, :) = start + find(diff==-1) - 2;     % 终点坐标


end

