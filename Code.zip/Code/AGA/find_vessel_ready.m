
% 输入：一条染色体，即一个行向量，输出：各码头的待分配船舶集合
function vessel_ready = find_vessel_ready (pop_repaired_i)
    
    global N_v L N_m
    
    % 进行向量化编程，缩短程序运行时间
    pop_repaired_i = reshape(pop_repaired_i, [N_v, 8])';    % 首先对矩阵的维度进行调整，变成 8×N_v 的矩阵
    vessel_ready = cell(1, N_m); 
    for m = 1 : N_m
        vessel_ready{1, m}(1, : ) = find(pop_repaired_i(1, : ) == m);    % 第一行：找出靠泊码头为m的船舶编号
        vessel_ready{1, m}(2, : ) = pop_repaired_i(3, pop_repaired_i(1, : ) == m);      % 第二行：船舶靠泊时间
        vessel_ready{1, m}(3, : ) = pop_repaired_i(6, pop_repaired_i(1, : ) == m);      % 第三行：船舶离港时刻
        vessel_ready{1, m}(4, : ) = pop_repaired_i(2, pop_repaired_i(1, : ) == m);      % 第四行：船舶靠泊位置
        vessel_ready{1, m}(5, : ) = L(pop_repaired_i(1, : ) == m);                                  % 第五行：船身长度
        vessel_ready{1, m}(6, : ) = pop_repaired_i(4, pop_repaired_i(1, : ) == m);      % 第六行：岸桥数量
        vessel_ready{1, m}(7, : ) = pop_repaired_i(5, pop_repaired_i(1, : ) == m);      % 第七行：岸桥起始编号
        vessel_ready{1, m}(8, : ) = pop_repaired_i(7, pop_repaired_i(1, : ) == m);      % 第八行：到港时刻松弛
        vessel_ready{1, m}(9, : ) = pop_repaired_i(8, pop_repaired_i(1, : ) == m);      % 第九行：岸桥效率松弛
    end
    
%     for m = 1 : N_m
%         % 码头 m 的待调度船舶集合
%         k = 0;
%         for j = 1 : N_v
%             if pop_repaired_i(j) == m
%                 k = k + 1;
%                 vessel_ready{1, m}(1, k) = j;                                                  % 第一行：待分配船舶编号
%                 vessel_ready{1, m}(2, k) = pop_repaired_i(j+2*N_v);         % 第二行：待分配船舶的靠泊时间
%                 vessel_ready{1, m}(3, k) = pop_repaired_i(j+5*N_v);         % 第三行：离港时刻
%                 vessel_ready{1, m}(4, k) = pop_repaired_i(j+N_v);             % 第四行：靠泊位置
%                 vessel_ready{1, m}(5, k) = L(j);                                              % 第五行：船身长度
%                 vessel_ready{1, m}(6, k) = pop_repaired_i(j+3*N_v);         % 第六行：岸桥数量
%                 vessel_ready{1, m}(7, k) = pop_repaired_i(j+4*N_v);         % 第七行：岸桥起始编号
%                 vessel_ready{1, m}(8, k) = pop_repaired_i(j+6*N_v);         % 第八行：到港时刻松弛
%                 vessel_ready{1, m}(9, k) = pop_repaired_i(j+7*N_v);         % 第九行：岸桥效率松弛
%             end
%         end
%     end
end