
% 输出：已完成调度的各码头船舶集合

function vessel_already = find_vessel_already ()
    
    global N_m d_0 C_0 Q_first_0 x_0 L_0 M_0
    % 各码头船舶信息集合
    % 进行向量化编程，缩短程序运行时间
    vessel_already = cell(1, N_m);
    for m = 1 : N_m
        vessel_already{1, m}(1, : ) = -find(M_0 == m);                     % 第一行：找出靠泊码头为m的船舶编号
        vessel_already{1, m}(2, : ) = 0;                                                % 第二行：船舶靠泊时间
        vessel_already{1, m}(3, : ) = d_0(M_0 == m);                       % 第三行：船舶离港时刻
        vessel_already{1, m}(4, : ) = x_0(M_0 == m);                        % 第四行：船舶靠泊位置
        vessel_already{1, m}(5, : ) = L_0(M_0 == m);                        % 第五行：船身长度
        vessel_already{1, m}(6, : ) = C_0(M_0 == m);                       % 第六行：岸桥数量
        vessel_already{1, m}(7, : ) = Q_first_0(M_0 == m);              % 第七行：岸桥起始编号
        vessel_already{1, m}(8, : ) = 0;                                               % 第八行：到港时刻松弛
        vessel_already{1, m}(9, : ) = 0;                                               % 第九行：岸桥效率松弛
    end
    
%     vessel_already = cell(1,N_m);
%     for m = 1 : N_m
%         k = 0;
%         for j = 1 : N_0
%             % 码头 i 的已调度船舶集合
%             if M_0(j) == m
%                 k = k + 1;
%                 vessel_already{1, m}(1, k) = -j;                        % 第一行：船舶编号
%                 vessel_already{1, m}(2, k) = 0;                         % 第二行：靠泊时刻
%                 vessel_already{1, m}(3, k) = d_0(j);                 % 第三行：离港时刻
%                 vessel_already{1, m}(4, k) = x_0(j);                  % 第四行：靠泊位置
%                 vessel_already{1, m}(5, k) = L_0(j);                  % 第五行：船身长度
%                 vessel_already{1, m}(6, k) = C_0(j);                  % 第六行：岸桥数量
%                 vessel_already{1, m}(7, k) = Q_first_0(j);         % 第七行：岸桥起始编号
%                 vessel_already{1, m}(8, k) = 0;                         % 第八行：到港时刻松弛
%                 vessel_already{1, m}(9, k) = 0;                         % 第九行：岸桥效率松弛
%             end
%         end
%     end
    
end
