
% 选择函数

function pop_select = select(pop_old, proba_choose)
    
    global popsize N_v
    
    pop_select = zeros(popsize, 8*N_v);
    
    for j = 1 : popsize
        r_select = rand(); % 确定一个概率，用于判断选择哪一个个体进入下一阶段
        pop_select(j, :) = pop_old(find(proba_choose >= r_select, 1), : );
        
    end
end
