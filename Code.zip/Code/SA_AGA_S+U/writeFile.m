clear;
clc;

global R_q cost_chidao sample g cost_work cost_diff N_m L_m d_m N_q v_m cost_tr N_0 M_0 W_0 L_0 x_0 C_0 Q_first_0 d_0 N_v L M_pre W_u W_d A A_sigma v_sigma ED C_min C_max draft best_position cost_delay popsize G_max  cost_stay p_0;

% 其他数据 %
g = 0.9;                                        % 岸桥干扰系数 %
cost_work = 5;                       % 单位时间单位岸桥作业成本 %   这些成本常量可以不用作为全局变量，只需放到 fitness 函数中即可
cost_stay = 3;                         % 单位时间非生产性停泊费用
cost_diff = 0.01;                          % 单位集装箱单位距离偏离成本 %
cost_chidao = 7;                     % 船舶迟到的单位时间成本

% 码头数据 %
N_m = 3;                                      % 码头数量 %
L_m = [1100, 1140, 1200];         % 岸线长度 %

N_q = [11, 12, 13];                       % 岸桥数量 %
v_m = [15, 15, 15];                         % 岸桥作业效率
% 码头间单位箱量转运成本 %
cost_tr = [     0,  2.15,  1.57;
                 3.16,       0,  2.29;
                 1.73,  1.47,       0];
% 水深条件 %
% 考虑潮汐因素后，码头的水深条件需要进行调整 %  行为码头编号（1~3），列为时间点（1~96）
d_m = readmatrix('E:/WorkSpace/paper_2/input/data_20.xlsx', 'Sheet', 'data_0', 'Range', 'I51:K146')';

R_q = cell(1, 3);                             % 岸桥的服务范围 %
R_q{1, 1} = readmatrix('E:/WorkSpace/paper_2/input/data_20.xlsx', 'Sheet', 'data_0', 'Range', 'C154:D164')';      % 码头一的岸桥服务范围矩阵
R_q{1, 2} = readmatrix('E:/WorkSpace/paper_2/input/data_20.xlsx', 'Sheet', 'data_0', 'Range', 'E154:F165')';      % 码头二的岸桥服务范围矩阵
R_q{1, 3} = readmatrix('E:/WorkSpace/paper_2/input/data_20.xlsx', 'Sheet', 'data_0', 'Range', 'G154:H166')';      % 码头三的岸桥服务范围矩阵



% 算法参数 %
popsize = 100;                   % 种群规模 %
G_max = 500;                     % 最大迭代次数 %
p_0 = 0.6;                            % 初始变异概率 %


% for k = 20:10:40  % 3个规模的数据    
    for i = 1 : 1  % 10个data


        % 已靠泊船舶 %
        N_0 = 8;                                       % 已靠泊船舶总数量 %
        %  已靠泊船舶汇总信息
        infor_0 = readmatrix('E:/WorkSpace/paper_2/input/data_20.xlsx', 'Sheet', ['data_', num2str(i)], 'Range', 'C17:H24')';
        M_0 = infor_0(1, : );                    % 所靠泊码头 %
        W_0 = infor_0(2, : );                    % 剩余作业量 %
        L_0 = infor_0(3, : );                      % 船舶长度 %
        x_0 = infor_0(4, : );                      % 靠泊位置 %
        C_0 = infor_0(5, : );                      % 岸桥数量 %
        Q_first_0 = infor_0(6, : );             % 起始岸桥编号 %
        clear infor_0;                                % 删除变量

        % 已靠泊船舶离港时刻
        for j = 1:N_0
            d_0(j) = round(W_0(j) / (C_0(j) * v_m(M_0(j)) * g^(C_0(j)-1)), 1);
        end

        % 待调度船舶 %
        N_v = 20;                                      % 待调度船舶数量 %
        %  待调度船舶信息汇总
        infor = readmatrix('E:/WorkSpace/paper_2/input/data_20.xlsx', 'Sheet', ['data_', num2str(i)], 'Range', 'C28:O47')';
        M_pre = infor(1, : );                      % 预分配码头 %
        W_u = infor(2, : );                          % 待装箱量 %
        W_d = infor(3, : );                          % 待卸箱量 %
        L = infor(4, : );                                % 船舶长度 %
        A = infor(5, : );                                % 船舶预计到港时刻 % 期望值
        ED = infor(6, : );                              % 期望离港时刻 %
        C_min = infor(7, : );                        % 最小岸桥数量 %
        C_max = infor(8, : );                        % 最大岸桥数量 %
        draft = infor(9, : );                           % 吃水深度 %
        best_position = infor(10, : );          % 偏好位置 %
        cost_delay = infor(11, : );               % 单位时间离港延迟惩罚 %
        A_sigma = infor(12, : );                   % 船舶预计到港时刻标准差
        v_sigma = infor(13, : );                    % 岸桥作业效率标准差
        clear infor;                                       % 删除变量

        % 样本数据 %  同码头成本系数，这些样本数据也可以直接放到 fitness 函数中
        sample = cell(1, 3);
        % 实际到达时间
        sample{1, 1} = readmatrix('E:/WorkSpace/paper_2/input/data_20.xlsx', 'Sheet', ['sample_', num2str(i), '_1'], 'Range', 'B4:U23');
        % 岸桥实际作业效率
        sample{1, 2} = readmatrix('E:/WorkSpace/paper_2/input/data_20.xlsx', 'Sheet', ['sample_', num2str(i), '_2'], 'Range', 'B4:U23');

        for j = 1 : 5   % 每个data运行5次
%             path = ["E:\WorkSpace\pap`er_2\output\result_40\data_7\run_", num2str(j), "\M+U\"] ;   % , num2str(k)
            filename_0 = ['E:\WorkSpace\paper_2\output\result_20\data_', num2str(i), '\run_', num2str(j), '\S+U\data_', num2str(i), '--run_', num2str(j), '.fig'];     % 适应度变化图文件名            ", num2str(i), "
            filename_1 = ['E:\WorkSpace\paper_2\output\result_20\data_', num2str(i), '\run_', num2str(j), '\S+U\data_', num2str(i), '--run_', num2str(j), '--terminal_1.fig'];     % 一码头靠泊图文件名
            filename_2 = ['E:\WorkSpace\paper_2\output\result_20\data_', num2str(i), '\run_', num2str(j), '\S+U\data_', num2str(i), '--run_', num2str(j), '--terminal_2.fig'];     % 二码头靠泊图文件名
            filename_3 = ['E:\WorkSpace\paper_2\output\result_20\data_', num2str(i), '\run_', num2str(j), '\S+U\data_', num2str(i), '--run_', num2str(j), '--terminal_3.fig'];     % 三码头靠泊图文件名
            filename_4 = ['E:\WorkSpace\paper_2\output\result_20\data_', num2str(i), '\run_', num2str(j), '\S+U\data_', num2str(i), '--run_', num2str(j), '.xlsx'];     % 变量存储文件
            filename_5 = ['E:\WorkSpace\paper_2\output\result_20\data_', num2str(i), '\run_', num2str(j), '\S+U\data_', num2str(i), '--run_', num2str(j), '.mat'];     % 变量存储文件
%             filename_5 = ['E:\WorkSpace\paper_2\output\result_40\data_8\run_', num2str(j), '\M+U\data_8--run_', num2str(j), '_value.mat'];
%             filename_6 = ['E:\WorkSpace\paper_2\output\result_40\data_8\run_', num2str(j), '\M+U\data_8--run_', num2str(j), '_pro.mat'];         
            [anwser, fitness_value_max, pro] = main();    % 运行一次程序，并返回想要的数据  
            disp(['finished: ', num2str((i-1)*5+j), '/50']);
            writematrix(anwser, filename_4, 'Sheet', 1, 'Range', 'B2 : I21');      % 写入最终的靠泊方案
            writematrix(fitness_value_max', filename_4, 'Sheet', 2, 'Range', 'B1 : B500');    % 写入最大适应度值
            writematrix(pro(:, size(pro, 2))', filename_4, 'Sheet', 3, 'Range', 'A2 : H2');       % 写入指标
            save(filename_5);
            saveas(1, filename_0);
            saveas(2, filename_1);
            saveas(3, filename_2);
            saveas(4, filename_3);
            close all;
        end
    end
% end